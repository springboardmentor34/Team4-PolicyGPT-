import { Component } from '@angular/core';
import { Router, RouterLink, RouterLinkActive } from '@angular/router';
import { Auth } from '../../../core/services/auth';

interface NavItem {
  label: string;
  route: string;
}

@Component({
  selector: 'app-navbar',
  standalone: true,
  imports: [RouterLink, RouterLinkActive],
  templateUrl: './navbar.html',
  styleUrl: './navbar.css',
})
export class Navbar {

  constructor(
    private router: Router,
    private auth: Auth
  ) {}

  get role(): string {
    return this.auth.getRoleFromToken()?.toLowerCase() || 'citizen';
  }

  get dashboardRoute(): string {
    switch (this.role) {
      case 'admin':
        return '/admin';

      case 'official':
        return '/official';

      case 'researcher':
        return '/researcher';

      case 'citizen':
      default:
        return '/citizen';
    }
  }

  get navItems(): NavItem[] {
    switch (this.role) {

      case 'admin':
        return [
          {
            label: 'Dashboard',
            route: '/admin'
          },
          {
            label: 'Policies',
            route: '/policies'
          },
          {
            label: 'Schemes',
            route: '/schemes'
          }
        ];

      case 'official':
        return [
          {
            label: 'Dashboard',
            route: '/official'
          },
          {
            label: 'Policies',
            route: '/policies'
          },
          {
            label: 'Schemes',
            route: '/schemes'
          },
          {
            label: 'Eligibility',
            route: '/eligibility'
          }
        ];

      case 'researcher':
        return [
          {
            label: 'Dashboard',
            route: '/researcher'
          },
          {
            label: 'Policies',
            route: '/policies'
          },
          {
            label: 'Schemes',
            route: '/schemes'
          }
        ];

      case 'citizen':
      default:
        return [
          {
            label: 'Dashboard',
            route: '/citizen'
          },
          {
            label: 'Policies',
            route: '/policies'
          },
          {
            label: 'Schemes',
            route: '/schemes'
          },
          {
            label: 'Eligibility',
            route: '/eligibility'
          }
        ];
    }
  }

  logout(): void {
    localStorage.removeItem('access_token');
    this.router.navigate(['/']);
  }
}